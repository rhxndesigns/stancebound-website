-- Run ONLY in your private Supabase SQL Editor. Do NOT upload this file to GitHub.
-- This seeds the two private Christmas accounts with bcrypt-hashed passcodes.
insert into public.christmas_users(username,display_name,pin_hash,theme) values
('rhxn1337','Ryan',extensions.crypt('242628',extensions.gen_salt('bf',12)),'stancebound'),
('smarie95','Shannon',extensions.crypt('260995',extensions.gen_salt('bf',12)),'pink')
on conflict(username) do update set display_name=excluded.display_name,pin_hash=excluded.pin_hash,theme=excluded.theme;
