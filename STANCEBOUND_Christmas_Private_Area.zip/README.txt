STANCEBOUND CHRISTMAS PRIVATE AREA

Backend tables, private image storage and christmas-private Edge Function have been deployed to Supabase.

REQUIRED SETUP:
1. Open Supabase SQL Editor for project fxlekwzcxedkiyqfswvq.
2. Paste/run SETUP_PRIVATE.sql. This adds the two login accounts. Keep this file PRIVATE; never upload it to GitHub.
3. Upload index.html from this folder to GitHub repo rhxndesigns/stancebound-website at christmas/index.html.
4. Visit https://stancebound.com/christmas/ (assuming the hosting configuration serves nested pages).
5. Sign in and test adding gifts, previews, chat and image attachments on both accounts.

Browser notifications are only checked while the Christmas page is open. This is not push notification delivery while the browser is closed. Automatic product previews depend on the retailer exposing Open Graph metadata.

Security note: Six-digit PINs are weak. Change them to long unique passwords before sharing the site widely. The website HTML does not contain either PIN, and the backend stores only password hashes.
